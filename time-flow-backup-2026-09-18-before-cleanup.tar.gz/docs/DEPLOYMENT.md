# Deploying TimeFlow to production

This guide is written against the actual repository layout:

| Part | Folder | Build | Start |
| --- | --- | --- | --- |
| Frontend (Next.js 15) | `frontend/` | `npm ci && npm run build` | Vercel runs it; self-hosted: `node server.js` in the Docker image |
| API (Express 5) | `backend/` | `npm ci && npm run build` | `npm run start` → `node dist/src/server.js` |
| Worker (BullMQ) | `backend/` (same build) | — | `npm run start:worker` → `node dist/src/worker.js` |
| Migrations + seed | `backend/` | — | `npx prisma migrate deploy && node dist/prisma/seed.js` |

## How requests flow

```
Browser ──https──▶ Vercel (Next.js) ──/api/*, /uploads/*, /admin/queues──▶ Render: timeflow-api ──▶ PostgreSQL
                                                                                  │                 ▲
                                                                                  └──▶ Redis ◀──────┤
                                                                                                    │
                                                              Render: timeflow-worker (emails, activity, inbox sync)
```

The browser **never calls the API domain directly**. `frontend/next.config.ts` rewrites
`/api/*` to `BACKEND_INTERNAL_URL`. Auth cookies are `HttpOnly; Secure; SameSite=Lax` and
belong to the frontend domain, so they keep working even though Vercel and Render are
different sites. That is why the frontend has no `NEXT_PUBLIC_API_URL`: calling the API
cross-site from the browser would turn these into third-party cookies, which browsers block.

## Chosen architecture

| Piece | Choice | Why |
| --- | --- | --- |
| Frontend | **Vercel** | Native Next.js hosting, zero config, preview deploys |
| API | **Render web service** (Docker, `backend/Dockerfile`) | Long-running Node process, SSE, health checks, pre-deploy migrations |
| Worker | **Render background worker** (same image) | BullMQ needs an always-on process; Vercel functions can't run it |
| PostgreSQL | **Render Postgres** | Same private network as the API, backups included |
| Redis | **Render Key Value** with `noeviction` | Same network; BullMQ loses jobs under eviction |

All four backend resources are declared in [`render.yaml`](../render.yaml), so Render creates
them in one step.

Alternatives, briefly:
- **Railway**: equally simple, billed by usage. You would create the same four services by hand.
- **AWS** (ECS/App Runner + RDS + ElastiCache): most control, but the most setup and operations work.
- **Single VPS** with [`docker-compose.prod.yml`](../docker-compose.prod.yml): cheapest. You handle OS updates and backups.
- **Free tiers**: not suitable. Render's free plan has no background workers or pre-deploy commands, and free web services sleep. BullMQ's constant polling uses up request-based Redis quotas such as Upstash's free plan.

Rough cost on Render paid plans at the time of writing: API starter + worker starter + Key Value
starter + Postgres basic ≈ US$30/month. Vercel Hobby is free for non-commercial use.
Check current pricing before you commit.

---

## STEP 1 → GitHub

The files added for deployment must be in the repository Render and Vercel read from:
`render.yaml`, `docker-compose.prod.yml`, `deploy/Caddyfile`, `.env.production.example`,
`docs/DEPLOYMENT.md` and the edited source files.

If your working folder is not a git checkout, copy it into a fresh clone:

```bash
git clone https://github.com/<you>/<repo>.git ~/timeflow-repo
rsync -av --exclude node_modules --exclude .next --exclude dist \
  --exclude '.env' --exclude '.env.test' --exclude .DS_Store --exclude test-results \
  --exclude '/backend/uploads' --exclude '/backend/uploads-test' \
  "/Users/mac/Documents/My Work/time flow/" ~/timeflow-repo/
cd ~/timeflow-repo
git status                      # review: no .env files may appear here
git check-ignore backend/.env   # prints the path = ignored
git add . && git commit -m "Prepare production deployment" && git push origin main
```

**Expected:** the GitHub Actions **CI** workflow runs and passes backend tests, frontend tests and the Docker image build.

## STEP 2 → PostgreSQL · STEP 3 → Redis · STEP 4 → Backend · STEP 5 → Worker

All four come from the Blueprint in a single flow.

1. Go to **dashboard.render.com → New → Blueprint**.
2. Connect GitHub and pick the repository, branch `main`. Render reads `render.yaml`.
3. Render lists `timeflow-db`, `timeflow-redis`, `timeflow-api` and `timeflow-worker`. It asks for the values marked `sync: false`:

| Variable | Value |
| --- | --- |
| `CORS_ORIGINS` | Your frontend URL, e.g. `https://timeflow.vercel.app` or `https://<site>.netlify.app`. Pick the project/site name now |
| `APP_URL` | Same as above (used in email links) |
| `JWT_ACCESS_SECRET` | Output of `openssl rand -base64 48` |
| `GMAIL_USER` | The sending Gmail address |
| `GMAIL_APP_PASSWORD` | 16-character App Password (STEP 10) |
| `SMTP_FROM` | `TimeFlow <the same gmail address>` |
| `ADMIN_EMAIL` | Your login for the first Super Admin |
| `ADMIN_PASSWORD` | A long password (8+ characters, at least one letter and one digit) |

4. Click **Apply**.

**What happens:**
- Postgres and Key Value are created.
- The backend image is built from `backend/Dockerfile`.
- `timeflow-api` runs the **pre-deploy command** `npx prisma migrate deploy && node dist/prisma/seed.js`. This applies all migrations in `backend/prisma/migrations`, syncs permissions and roles, and creates `ADMIN_EMAIL`. No demo accounts are created in production.
- The API starts and must pass `GET /health/ready`.
- `timeflow-worker` starts with `node dist/src/worker.js`.

**Expected results:**
- `https://timeflow-api.onrender.com/health/ready` returns `{"status":"ok","checks":{"database":{"status":"up",…},"redis":{"status":"up",…}}}`.
- The `timeflow-api` pre-deploy log contains `Created Super Admin you@…`.
- The `timeflow-worker` log contains `worker started` and `SMTP connection successful`.
- Neither log shows a `COOKIE_SECURE` / `JWT_ACCESS_SECRET` / `APP_URL` warning. The server lists these on startup if a value is unsafe.

After the first successful deploy you may delete `ADMIN_PASSWORD` from the API's environment.
The seed never changes an existing account.

## STEP 6 → Environment variables

The full annotated list is in [`.env.production.example`](../.env.production.example).
Backend values live in the Render env group **timeflow-backend**, which the API and worker share.

| Where | Variable | Production value |
| --- | --- | --- |
| Render (group) | `NODE_ENV` | `production` |
| Render (group) | `COOKIE_SECURE` | `true` |
| Render (group) | `TRUST_PROXY` | `2` (verify in STEP 12) |
| Render (group) | `CORS_ORIGINS` / `APP_URL` | `https://<frontend-domain>` |
| Render (group) | `JWT_ACCESS_SECRET` | random, ≥ 32 characters, **identical for API and worker** |
| Render (group) | `EMAIL_PROVIDER`, `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `SMTP_FROM` | see STEP 10 |
| Render (group) | `SEED_DEMO_DATA` | `false` |
| Render (group) | `EMAIL_FAILURE_RATE` | `0` |
| Render (automatic) | `DATABASE_URL`, `REDIS_URL` | wired by the Blueprint |
| Render (automatic) | `PORT` | injected by Render |
| Render (API only) | `ADMIN_EMAIL`, `ADMIN_PASSWORD` | first admin |
| Vercel | `BACKEND_INTERNAL_URL` | `https://timeflow-api.onrender.com` (or `https://api.<your-domain>`) |

Never set `NEXT_PUBLIC_SHOW_DEMO_ACCOUNTS=true` in production.

## STEP 7 → Frontend (Vercel)

1. Go to **vercel.com → Add New… → Project** and import the GitHub repository.
2. Set **Root Directory** to `frontend`. Vercel detects Next.js; leave the build command as `npm run build`.
3. Under **Environment Variables**, add `BACKEND_INTERNAL_URL` = `https://timeflow-api.onrender.com` (no trailing slash) for Production and Preview.
4. Click **Deploy**.

**Expected:** the build finishes with 20 routes and `https://<project>.vercel.app/login` shows the sign-in form without the "Demo accounts" section.
If `BACKEND_INTERNAL_URL` is missing, the build **fails on purpose** with a message saying so.
Rewrites are fixed at build time, so **redeploy** after changing this variable.

### STEP 7 (alternative) → Frontend on Netlify

Netlify can host the frontend in place of Vercel. It cannot run the API or the worker, so those still go to Render (or any host with a public HTTPS URL).

1. Push the repository to GitHub. **Drag-and-drop deploys do not work**: they upload static files, and this is a server-rendered Next.js app, so every URL returns Netlify's "Page not found".
2. **netlify.com → Add new site → Import an existing project** and pick the repository. The root [`netlify.toml`](../netlify.toml) sets the base directory to `frontend`, the build command, and the Next.js runtime. Leave the UI fields empty; if you fill them, use **Base directory** `frontend`, **Build command** `npm run build`, **Publish directory** `frontend/.next`.
3. **Site configuration → Environment variables:** add `BACKEND_INTERNAL_URL` = `https://timeflow-api.onrender.com` (no trailing slash).
4. **Deploys → Trigger deploy → Clear cache and deploy site.**
5. On Render, add the Netlify origin (`https://<site>.netlify.app`) to `CORS_ORIGINS` and set `APP_URL` to it.

**Expected:** `https://<site>.netlify.app/login` shows the sign-in form. A missing `BACKEND_INTERNAL_URL` fails the build with a message saying so.

If you see Netlify's own "Page not found" page, the build did not produce a Next.js site. Check that the deploy log shows `@netlify/plugin-nextjs` running and the base directory `frontend`.

## STEP 8 → CORS

`CORS_ORIGINS` on Render must list the exact frontend origin(s), comma-separated, without a trailing slash:

```
CORS_ORIGINS=https://timeflow.vercel.app,https://app.example.com
```

The API echoes only listed origins and sends credentials only to them. It never uses `*`.
Because the browser reaches the API through the Vercel proxy, CORS is a safeguard here, not something the app depends on.

## STEP 9 → Domain

- **Frontend:** Vercel → Project → **Settings → Domains → Add** `app.example.com`. Create the DNS record Vercel shows, usually `CNAME app → cname.vercel-dns.com`. HTTPS is issued automatically.
- **API (optional):** Render → `timeflow-api` → **Settings → Custom Domains → Add** `api.example.com`. Create `CNAME api → timeflow-api.onrender.com`.
- Then update the dependent values:
  - Vercel: `BACKEND_INTERNAL_URL=https://api.example.com`, then **Redeploy**.
  - Render env group: `CORS_ORIGINS` and `APP_URL` = `https://app.example.com`. Render restarts both services.

## STEP 10 → SMTP

**Gmail (current setup):**
1. Go to **myaccount.google.com → Security** and turn on **2-Step Verification**.
2. Open **App passwords** and create one named "TimeFlow". Copy the 16 characters without spaces.
3. On Render, set `EMAIL_PROVIDER=gmail`, `GMAIL_USER=<address>`, `GMAIL_APP_PASSWORD=<16 chars>` and `SMTP_FROM=TimeFlow <address>`.
4. Reply import (`INBOUND_SYNC_ENABLED=true`) reads this mailbox over IMAP. Make sure IMAP is enabled in **Gmail → Settings → Forwarding and POP/IMAP**.

Gmail limits a personal account to roughly 500 recipients a day. For more volume, use a transactional provider:

```
EMAIL_PROVIDER=smtp
SMTP_HOST=smtp.sendgrid.net      # or smtp.resend.com, email-smtp.<region>.amazonaws.com …
SMTP_PORT=587
SMTP_SECURE=false                # true only for port 465
SMTP_USER=apikey                 # provider-specific
SMTP_PASS=<key>                  # SMTP_PASSWORD also works
SMTP_FROM=TimeFlow <no-reply@your-verified-domain>
```

A Super Admin can also save the mail account in the app under **System → Email delivery**.
That setting overrides the variables above, and the password is stored encrypted with `JWT_ACCESS_SECRET`.

**Expected:** the worker log shows `SMTP connection successful`, and creating a user sends a welcome email.

## STEP 11 → Production migration

Migrations run automatically before every API deploy (pre-deploy command). To run them manually,
open Render → `timeflow-api` → **Shell** and run:

```bash
npx prisma migrate deploy        # apply pending migrations; never drops data
node dist/prisma/seed.js         # sync roles/permissions; create ADMIN_EMAIL if missing
npx prisma migrate status        # confirm "Database schema is up to date"
```

**Never** run `prisma migrate dev`, `prisma migrate reset`, `npm run db:reset` or `prisma db push`
against production. They can drop data or leave the migration history out of sync with the database.

New schema changes follow this workflow:
1. Create the migration locally with `npm run db:migrate` (or write the SQL by hand).
2. Commit the new folder under `backend/prisma/migrations/`.
3. Push. The next deploy applies it.

## STEP 12 → Final testing

Go through this list on the production URL:

- [ ] `https://<api>/health/ready` returns `status: ok`.
- [ ] `https://<frontend>/login` loads over HTTPS with no "Demo accounts" section.
- [ ] Logging in as `ADMIN_EMAIL` works. DevTools → Application → Cookies shows `tf_access` as `HttpOnly` and `Secure` on the frontend domain.
- [ ] `superadmin@timeflow.dev` / `Password123!` is **rejected**.
- [ ] Refreshing the page after 15+ minutes keeps you logged in (the refresh token works through the proxy).
- [ ] Create a user: a welcome email arrives, and **System → Queues** shows the job as completed.
- [ ] Assign a task: the assignee gets a notification without reloading (the SSE stream works through Vercel) and an email.
- [ ] Upload an avatar: it displays. Note that it disappears after the next API deploy (see Uploads below).
- [ ] **Activity** shows your real public IP for the login. If it shows a Vercel/Render address, adjust `TRUST_PROXY` (below).
- [ ] Six wrong passwords in a minute returns "Too many login attempts".
- [ ] `/admin/queues` opens for a Super Admin and returns 401/403 when logged out.
- [ ] Restarting the worker in Render logs `worker stopped cleanly` and then `worker started`.

---

## Things to know

### `TRUST_PROXY`
Rate limiting and the audit log use the client IP taken from `X-Forwarded-For`. `TRUST_PROXY`
is how many proxies to trust in front of the API: Vercel's proxy plus Render's load balancer
gives `2`. If Activity shows a non-client IP, raise or lower the value by one and re-check.
If it is too low, every user shares one IP, and the login limit of 5 per minute then applies
to everyone at once. If it is too high, clients can spoof their IP.

### Uploads (avatars)
Avatars are written to `UPLOAD_DIR=/app/uploads` on the API container's disk, which Render wipes on each deploy.
The options are:
1. **Accept it** for now. Users re-upload their avatar after a deploy.
2. **Add a Render disk** (`disk:` with `mountPath: /app/uploads` on `timeflow-api`). The image runs as the non-root user `app`, so first check that the mounted path is writable. If the API fails at boot with `EACCES`, the disk's ownership needs fixing. A disk also limits the API to one instance.
3. **Move to object storage** (S3/R2). This needs a code change in `backend/src/modules/uploads/upload.routes.ts`.

The self-hosted compose file already stores uploads in a named volume.

### Notifications stream through Vercel
`/api/notifications/stream` is a long-lived SSE response proxied by Vercel. If Vercel closes it after
a while, the client reconnects automatically (`frontend/hooks/use-notifications.ts`). Check in
STEP 12 that notifications arrive live.

### Rollback
Render → service → **Events / Deploys → Rollback**. Vercel → **Deployments → … → Promote**.
Migrations only move forward, so a rollback that crosses a schema change needs a new migration instead.

### Scaling
- API: add instances in Render (it is stateless apart from uploads, see above).
- Worker: add instances. The inbox poll scheduler is keyed, so replicas don't duplicate it. Increase `WORKER_CONCURRENCY` for more parallel jobs.

---

## Alternative: single VPS with Docker

Requirements: a Linux server with Docker, ports 80/443 open, and a DNS A record pointing at it.

```bash
git clone https://github.com/<you>/<repo>.git timeflow && cd timeflow
cp .env.production.example .env.production
# edit: DOMAIN, POSTGRES_PASSWORD (openssl rand -hex 32), JWT_ACCESS_SECRET,
#       ADMIN_EMAIL, ADMIN_PASSWORD, GMAIL_USER, GMAIL_APP_PASSWORD, SMTP_FROM
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
docker compose -f docker-compose.prod.yml --env-file .env.production logs -f migrate backend worker
```

- Caddy obtains HTTPS for `DOMAIN` and forwards everything to Next.js, which proxies `/api` to the backend. Only one domain is needed.
- Postgres, Redis and the API publish no ports.
- To update: `git pull`, then run the same `up -d --build`. Migrations run again automatically.
- Backups are your job, e.g. a nightly `docker compose -f docker-compose.prod.yml exec postgres pg_dump -U timeflow timeflow > backup.sql`.

The plain `docker-compose.yml` remains the **local demo** stack: demo data, Mailpit and HTTP cookies.
