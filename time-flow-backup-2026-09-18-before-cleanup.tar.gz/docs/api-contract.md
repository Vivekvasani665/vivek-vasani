# TimeFlow — API Contract

Source of truth shared by `backend/` and `frontend/`. The interactive, machine-readable
version is served by the API at `GET /api/docs` (Swagger UI) and `GET /api/docs.json`.

## Conventions

- Base path: `/api`. JSON everywhere, dates as ISO-8601 strings. Date-only fields
  (`startDate`, `endDate`, `dueDate`) are sent as `YYYY-MM-DD` and returned as ISO strings.
- IDs are UUID v4.
- Enum values are UPPER_SNAKE (`ON_HOLD`, `IN_PROGRESS`); the UI maps them to labels.
- Every response carries an `X-Request-Id` header (echoed from the request if provided).

### Success envelope

```json
{ "success": true, "data": {}, "message": "User created successfully" }
```

List endpoints add `meta`:

```json
{ "success": true, "data": [], "meta": { "page": 1, "limit": 10, "total": 42, "totalPages": 5 } }
```

### Error envelope

```json
{
  "success": false,
  "message": "Validation failed",
  "code": "VALIDATION_ERROR",
  "details": [{ "path": "email", "message": "Invalid email address" }],
  "requestId": "b1f0…"
}
```

| HTTP | code                    | when                                              |
| ---- | ----------------------- | ------------------------------------------------- |
| 400  | `VALIDATION_ERROR`      | body/query/params failed schema validation         |
| 400  | `BAD_REQUEST`           | semantically invalid (e.g. endDate < startDate)    |
| 401  | `UNAUTHENTICATED`       | missing/invalid/expired access token               |
| 401  | `INVALID_CREDENTIALS`   | wrong email/password                               |
| 403  | `FORBIDDEN`             | authenticated but lacks permission / scope         |
| 403  | `ACCOUNT_INACTIVE`      | login attempt on an inactive account               |
| 404  | `NOT_FOUND`             | entity missing, soft-deleted, or outside scope     |
| 409  | `USER_EMAIL_EXISTS`     | duplicate email                                    |
| 409  | `ROLE_NAME_EXISTS`      | duplicate role name                                |
| 409  | `ROLE_IN_USE`           | deleting a role that still has users               |
| 409  | `CONFLICT`              | other unique/state conflicts                       |
| 413  | `PAYLOAD_TOO_LARGE`     | upload too big                                     |
| 429  | `RATE_LIMITED`          | rate limit hit (`Retry-After` header set)          |
| 500  | `INTERNAL_ERROR`        | unexpected                                         |

### List query parameters (shared)

`page` (default 1), `limit` (default 10, max 100), `search`, `sortBy`, `sortOrder` (`asc`|`desc`, default `desc`).

## Authentication

- `POST /api/auth/login` sets two **httpOnly** cookies:
  - `tf_access` — JWT (HS256, 15 min), path `/`.
  - `tf_refresh` — opaque random token (7 days), path `/api/auth`. Stored hashed; rotated on every refresh; reuse of a rotated token revokes the whole token family.
- The API also accepts `Authorization: Bearer <access token>` (used by Swagger / scripts / tests).
- The frontend talks to the API **same-origin** through a Next.js rewrite (`/api/*` → backend), so cookies are first-party and no CORS preflight is needed from the browser.
- Also sets `tf_session=1` (httpOnly, path `/`, same expiry as the refresh token): a non-secret marker so page middleware knows a refreshable session exists.
- Every authenticated response (and login/refresh) carries `X-Session-Expires-At` (ISO) — the access token expiry. The client refreshes ~60 s before it.
- On `401 UNAUTHENTICATED` the client calls `POST /api/auth/refresh` once and retries the original request; if refresh fails it redirects to `/login`.

| Method | Path                  | Auth | Body / Notes |
| ------ | --------------------- | ---- | ------------ |
| POST   | `/api/auth/login`     | –    | `{ email, password }` → `data: { user: AuthUser }`. Rate limited 5/min/IP. |
| PATCH  | `/api/auth/me/preferences` | any signed-in user | Partial `{ theme, accent, density }`; merged server-side and returned whole. No permission — these are the caller's own UI settings. |
| GET    | `/api/auth/me/sessions` | any signed-in user | Active sign-ins, one per refresh-token family: `{ familyId, ipAddress, userAgent, lastSeenAt, expiresAt, current }[]`. |
| DELETE | `/api/auth/me/sessions/{familyId}` | any signed-in user | Revokes that family. The device keeps a working access token until it expires (15 min), then cannot refresh. |
| POST   | `/api/auth/me/sessions/revoke-others` | any signed-in user | Revokes every family except the caller's → `{ revoked }`. |
| POST   | `/api/auth/refresh`   | cookie | → `data: { user: AuthUser }`, rotates cookies |
| POST   | `/api/auth/logout`    | –    | revokes refresh token family, clears cookies |
| GET    | `/api/auth/me`        | yes  | → `data: AuthUser` |

```ts
type AuthUser = {
  id: string; firstName: string; lastName: string; email: string;
  phone: string | null; avatarUrl: string | null; status: "ACTIVE" | "INACTIVE";
  role: { id: string; name: string };
  permissions: string[];         // e.g. ["users.view", "projects.view_all", ...]
  lastLoginAt: string | null; createdAt: string;
};
```

## Permissions (RBAC)

| module          | actions                                           |
| --------------- | ------------------------------------------------- |
| `users`         | `view`, `create`, `update`, `delete`              |
| `roles`         | `view`, `create`, `update`, `delete`              |
| `projects`      | `view`, `create`, `update`, `delete`, `view_all`  |
| `tasks`         | `view`, `create`, `update`, `delete`, `view_all`  |
| `activity_logs` | `view`, `export`                                  |
| `emails`        | `view`, `send`, `send_external`, `view_all`       |
| `queues`        | `view`, `manage`                                  |

`*.view_all` lifts **data scoping**. Without it:
- Projects visible = projects where the user is manager **or** member.
- Tasks visible = tasks assigned to the user, created by the user, or belonging to a project the user manages.
- A user who is neither the task's project manager nor holds `tasks.view_all` may only change `status` of tasks assigned to them.
- Updating/deleting a project requires the permission **and** (`projects.view_all` or being its manager).

Escalation guards (enforced in services):
- You cannot assign a role (to a user) that has permissions you do not hold.
- You cannot grant a role permissions you do not hold.
- You cannot delete or deactivate yourself, or change your own role.
- System roles cannot be deleted; the `Super Admin` role's permissions cannot be changed.

Seeded roles: **Super Admin** (all), **Admin** (all except `roles.create|update|delete`, `queues.manage`),
**Manager** (`users.view`, `projects.view|create|update`, `tasks.*` except `view_all`, `activity_logs.view`),
**Employee** (`projects.view`, `tasks.view`, `tasks.update`).

Seeded logins (password `Password123!`): `superadmin@timeflow.dev`, `admin@timeflow.dev`,
`manager@timeflow.dev`, `employee@timeflow.dev`.

## Resources

### Shared shapes

```ts
type UserRef = { id: string; firstName: string; lastName: string; email: string; avatarUrl: string | null };

type User = UserRef & {
  phone: string | null; status: "ACTIVE" | "INACTIVE";
  role: { id: string; name: string };
  lastLoginAt: string | null; createdAt: string; updatedAt: string;
  // detail endpoint only:
  stats?: { assignedTasks: number; completedTasks: number; projects: number };
};

type Permission = { id: string; key: string; module: string; action: string; description: string | null };

type Role = {
  id: string; name: string; description: string | null; isSystem: boolean;
  permissions: string[];              // permission keys
  userCount: number;
  createdAt: string; updatedAt: string;
};

type Project = {
  id: string; name: string; description: string | null;
  status: "PLANNING" | "ACTIVE" | "ON_HOLD" | "COMPLETED" | "ARCHIVED";
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  startDate: string; endDate: string | null;
  manager: UserRef; members: UserRef[];
  taskStats: { total: number; completed: number };   // progress bar
  createdAt: string; updatedAt: string;
};

type Task = {
  id: string; title: string; description: string | null;
  project: { id: string; name: string };
  assignee: UserRef | null; createdBy: UserRef | null;
  status: "TODO" | "IN_PROGRESS" | "REVIEW" | "COMPLETED";
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  dueDate: string | null; completedAt: string | null;
  createdAt: string; updatedAt: string;
};

type ActivityLog = {
  id: string; action: string; entity: string; entityId: string | null;
  description: string; metadata: Record<string, unknown>;
  ipAddress: string | null; user: UserRef | null; createdAt: string;
};

type Notification = {
  id: string; type: string; title: string; body: string | null; link: string | null;
  readAt: string | null; createdAt: string;
};
```

### Users — `users.*`

| Method | Path                       | Permission     | Notes |
| ------ | -------------------------- | -------------- | ----- |
| GET    | `/api/users`               | `users.view`   | query: `search` (name/email/phone), `status`, `roleId`, `sortBy` ∈ `createdAt,firstName,lastName,email,status,lastLoginAt` |
| POST   | `/api/users`               | `users.create` | `{ firstName, lastName, email, phone?, password, roleId, status?, avatarUrl? }` → 201. Enqueues welcome email. |
| GET    | `/api/users/:id`           | `users.view`   | includes `stats` |
| PATCH  | `/api/users/:id`           | `users.update` | any of `firstName,lastName,email,phone,password,roleId,status,avatarUrl` |
| PATCH  | `/api/users/:id/status`    | `users.update` | `{ status }` |
| DELETE | `/api/users/:id`           | `users.delete` | soft delete, revokes sessions |
| GET    | `/api/users/options`       | authenticated  | `UserRef[]` of active users (for pickers; max 200, `search` supported) |

Password rules: min 8 chars, at least one letter and one number.

### Uploads

| POST | `/api/uploads/avatar` | authenticated | `multipart/form-data` field `file` (png/jpeg/webp, ≤ 2 MB) → `data: { url }` (`/uploads/avatars/<file>`) |

Uploaded files are served at `/uploads/*` (also proxied by the frontend).

### Roles & permissions

| Method | Path                     | Permission     | Notes |
| ------ | ------------------------ | -------------- | ----- |
| GET    | `/api/permissions`       | `roles.view`   | `data: Permission[]` (sorted by module, action) |
| GET    | `/api/roles`             | `roles.view`   | `search`, pagination; `sortBy` ∈ `name,createdAt` |
| POST   | `/api/roles`             | `roles.create` | `{ name, description?, permissions: string[] }` |
| GET    | `/api/roles/:id`         | `roles.view`   | |
| PATCH  | `/api/roles/:id`         | `roles.update` | `{ name?, description?, permissions? }` (replaces set, in a transaction) |
| DELETE | `/api/roles/:id`         | `roles.delete` | 409 `ROLE_IN_USE` if users assigned |
| GET    | `/api/roles/:id/users`   | `roles.view`   | paginated `User[]` |

### Projects

| Method | Path                  | Permission        | Notes |
| ------ | --------------------- | ----------------- | ----- |
| GET    | `/api/projects`       | `projects.view`   | **Redis cached** (`X-Cache: HIT|MISS`). query: `search`, `status`, `priority`, `managerId`, `sortBy` ∈ `createdAt,name,startDate,endDate,priority,status` |
| POST   | `/api/projects`       | `projects.create` | `{ name, description?, status?, priority?, startDate, endDate?, managerId, memberIds?: string[] }` |
| GET    | `/api/projects/:id`   | `projects.view`   | scoped |
| PATCH  | `/api/projects/:id`   | `projects.update` | same fields, all optional; `memberIds` replaces set |
| DELETE | `/api/projects/:id`   | `projects.delete` | soft delete (tasks soft-deleted in same transaction) |

### Tasks

| Method | Path                  | Permission     | Notes |
| ------ | --------------------- | -------------- | ----- |
| GET    | `/api/tasks`          | `tasks.view`   | query: `search`, `status`, `priority`, `projectId`, `assigneeId` (`me` allowed), `sortBy` ∈ `createdAt,title,dueDate,priority,status` |
| POST   | `/api/tasks`          | `tasks.create` | `{ title, description?, projectId, assigneeId?, status?, priority?, dueDate? }`; assignee must be the project manager or a member |
| GET    | `/api/tasks/:id`      | `tasks.view`   | scoped |
| PATCH  | `/api/tasks/:id`      | `tasks.update` | all optional; status transitions logged; `completedAt` maintained |
| DELETE | `/api/tasks/:id`      | `tasks.delete` | soft delete |

### Activity logs

| GET | `/api/activity-logs`        | `activity_logs.view`   | query: `search`, `entity`, `action`, `userId`, `from`, `to` (ISO dates) |
| GET | `/api/activity-logs/export` | `activity_logs.export` | same filters → `text/csv` stream |

### Dashboard

`GET /api/dashboard` (authenticated, Redis cached, scoped by permissions):

```ts
{
  stats: { totalUsers: number | null; activeUsers: number | null;   // null if no users.view
           totalProjects: number; activeProjects: number; totalTasks: number; completedTasks: number };
  tasksByStatus: { status: TaskStatus; count: number }[];
  projectsByStatus: { status: ProjectStatus; count: number }[];
  recentProjects: Project[];               // 5
  recentActivity: ActivityLog[];           // 8, [] if no activity_logs.view
  myTasks: Task[];                         // 5 open tasks assigned to me, by due date
}
```

### Notifications

| GET   | `/api/notifications`             | authenticated | `unread=true` filter; `meta.unread` = unread count |
| PATCH | `/api/notifications/:id/read`    | authenticated | |
| POST  | `/api/notifications/read-all`    | authenticated | |
| GET   | `/api/notifications/stream`      | authenticated | `text/event-stream`; event `notification` with `Notification` JSON (Redis pub/sub fan-out) |

### Queues (monitoring)

| GET  | `/api/queues`                              | `queues.view`   | `data: { name, counts: { waiting, active, completed, failed, delayed } }[]` |
| GET  | `/api/queues/:name/jobs?state=failed`      | `queues.view`   | `state` ∈ `waiting,active,completed,failed,delayed`; `{ id, name, data, attemptsMade, failedReason, timestamp, finishedOn }[]` (sensitive fields stripped) |
| POST | `/api/queues/:name/jobs/:id/retry`         | `queues.manage` | |
| —    | `/admin/queues`                            | `queues.view`   | Bull Board UI (cookie auth) |

Queues: `email`, `activity`, `email-dead-letter`.

### Mailbox — `emails.*`

| Method | Path | Permission | Notes |
| ------ | ---- | ---------- | ----- |
| GET   | `/api/emails`              | `emails.view` | Paginated `EmailLog[]`. `box` ∈ `inbox` (addressed to you), `sent` (your actions produced it), `all` (everything — additionally requires `emails.view_all`). Also `status`, `search`, `unreadOnly`. Bodies are omitted from list rows. |
| POST  | `/api/emails`              | `emails.send` (+ `emails.send_external` for non-members) | `{ toUserId \| toEmail, subject, body }` — exactly one recipient field. An address belonging to an active user resolves to them, so it reaches their Inbox as well as SMTP. Any other address is SMTP-only from the org sender identity and needs `emails.send_external`; an address belonging to a deactivated account is rejected `400`. → `201 { id }` |
| GET   | `/api/emails/stats`        | `emails.view` | `{ total, queued, sent, failed, unread, last24h, scope }`. `scope` is `all` for `emails.view_all` holders, else `own`. |
| GET   | `/api/emails/:id`          | `emails.view` | Full `EmailDetail` with `bodyHtml` / `bodyText`. You must be recipient or sender unless you hold `emails.view_all`. |
| PATCH | `/api/emails/:id/read`     | `emails.view` | `{ read: boolean }`. Recipient only — a message in Sent has no read state. |

### Health

`GET /health/live` → 200 always. `GET /health/ready` → 200 when Postgres and Redis respond, else 503.
