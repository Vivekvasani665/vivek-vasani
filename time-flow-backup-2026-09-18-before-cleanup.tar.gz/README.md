# TimeFlow // Command Center

A production-style **Team & Project Management system** with role-based access control. The UI is styled like a sci-fi game HUD.

`Next.js 15` · `Express 5` · `TypeScript` · `PostgreSQL + Prisma` · `Redis` · `BullMQ` · `Docker`

![Dashboard](docs/screenshots/dashboard.png)

| Login | Projects | System monitor |
| --- | --- | --- |
| ![Login](docs/screenshots/login.png) | ![Projects](docs/screenshots/projects.png) | ![System](docs/screenshots/system.png) |
| **Role permission matrix** | **Employee task view (status-only)** | |
| ![Roles](docs/screenshots/role-permissions.png) | ![Employee task](docs/screenshots/employee-task.png) | |

---

## Contents

1. [Quick start](#quick-start)
2. [Demo accounts](#demo-accounts)
3. [Local development without Docker](#local-development-without-docker)
4. [Environment variables](#environment-variables)
5. [Database](#database)
6. [Architecture](#architecture)
7. [Authentication](#authentication)
8. [RBAC](#rbac)
9. [Mailbox](#mailbox)
10. [Outgoing mail](#outgoing-mail)
11. [Settings](#settings)
12. [Caching & rate limiting](#caching--rate-limiting)
13. [Background jobs](#background-jobs)
14. [Security](#security)
15. [Error handling & logging](#error-handling--logging)
16. [Testing](#testing)
17. [API documentation](#api-documentation)
18. [Demo script](#demo-script)
19. [Design decisions & trade-offs](#design-decisions--trade-offs)

---

## Quick start

```bash
docker compose up --build
```

| Service | URL |
| --- | --- |
| Frontend | http://localhost:3000 |
| API | http://localhost:4000 |
| Swagger UI | http://localhost:4000/api/docs |
| Bull Board (queue UI) | http://localhost:4000/admin/queues (log in first) |
| Mailpit (caught emails) | http://localhost:8025 |
| Health | http://localhost:4000/health/ready |

Compose starts `postgres`, `redis`, `mailpit`, a one-shot `migrate` container, `backend`, `worker` and `frontend`. The `migrate` container runs `prisma migrate deploy` and the idempotent seed. `backend` and `worker` wait until it has finished successfully.

No `.env` file is required. Every variable has a development-only default in `docker-compose.yml`. For anything beyond local use, copy `.env.example` to `.env` and set real secrets.

**Production:** see [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) (Vercel + Render via [`render.yaml`](render.yaml), or a single VPS via `docker-compose.prod.yml`) and [`.env.production.example`](.env.production.example). Demo accounts are not seeded when `NODE_ENV=production`.

## Demo accounts

Password for all accounts: **`Password123!`**. The login screen also has one-click "Select demo player" chips.

| Email | Role | What to try |
| --- | --- | --- |
| `superadmin@timeflow.dev` | Super Admin | Everything, including roles and queue retries |
| `admin@timeflow.dev` | Admin | Manage users, projects, tasks; can't edit roles |
| `manager@timeflow.dev` | Manager | Own projects and their tasks; read-only users |
| `employee@timeflow.dev` | Employee | Only assigned projects/tasks; can only change the status of tasks assigned to them |

## Local development without Docker

Requirements: Node 22+, PostgreSQL 14+, Redis 6+.

```bash
# Backend (API + worker)
cd backend
cp ../.env.example .env              # then set DATABASE_URL / REDIS_URL; SMTP_HOST empty = log emails only
npm install
npm run db:deploy && npm run db:seed
npm run dev                          # API on :4000
npm run dev:worker                   # in a second terminal

# Frontend
cd frontend
npm install
npm run dev                          # http://localhost:3000 (proxies /api to BACKEND_INTERNAL_URL)
```

## Environment variables

All of them are documented inline in [`.env.example`](.env.example). The backend validates them with zod at boot (`backend/src/config/env.ts`) and stops immediately with a readable error if any are wrong.

| Variable | Used by | Description |
| --- | --- | --- |
| `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_DB` | compose | Credentials for the Postgres container |
| `DATABASE_URL` | backend, worker | Prisma connection string |
| `REDIS_URL` | backend, worker | Cache, rate limiting, BullMQ, pub/sub |
| `NODE_ENV` | backend | `development` / `production` / `test` |
| `PORT` | backend | API port (default 4000) |
| `LOG_LEVEL` | backend, worker | pino level (`info`, `debug`, `silent`, …) |
| `TRUST_PROXY` | backend | Proxy hops to trust when resolving the client IP |
| `CORS_ORIGINS` | backend | Comma-separated allowlist of origins |
| `APP_URL` | worker | Frontend URL used in email links |
| `JWT_ACCESS_SECRET` | backend | HS256 signing secret (≥ 32 chars) |
| `ACCESS_TOKEN_TTL_MINUTES` | backend | Access JWT lifetime (default 15) |
| `REFRESH_TOKEN_TTL_DAYS` | backend | Refresh token lifetime (default 7) |
| `COOKIE_SECURE` | backend | Set `true` behind HTTPS |
| `CACHE_TTL_SECONDS` | backend | TTL for cached responses |
| `RATE_LIMIT_LOGIN_MAX` / `RATE_LIMIT_LOGIN_WINDOW_SECONDS` | backend | Login limit (5 / 60 s per IP) |
| `RATE_LIMIT_API_MAX` / `RATE_LIMIT_API_WINDOW_SECONDS` | backend | Global API limit per IP |
| `RATE_LIMIT_EMAIL_MAX` / `RATE_LIMIT_EMAIL_WINDOW_SECONDS` | backend | Compose limit, counted **per user** (20 / 60 s). Sending emits real mail from the org identity |
| `EMAIL_PROVIDER` | worker | `mailpit` \| `gmail` \| `smtp` \| `log`. Picks the transport outright; leave blank to infer it from `SMTP_HOST` as before |
| `EMAIL_ALLOW_REAL_SEND` | worker | Outside `NODE_ENV=production`, a provider that reaches real inboxes is refused unless this is `true` |
| `GMAIL_USER` / `GMAIL_APP_PASSWORD` | worker | The official Gmail account and its **16-character App Password**. Used by `EMAIL_PROVIDER=gmail`; mail always leaves as `GMAIL_USER` |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_FROM` | worker | SMTP settings. **An empty host only logs mail** — nodemailer still returns a `messageId`, so a "completed" job delivers nothing |
| `SMTP_SECURE` | worker | Implicit TLS. `true` for port 465; `false` for 587/25, which use STARTTLS |
| `SMTP_USER` / `SMTP_PASS` (alias `SMTP_PASSWORD`) | worker | Credentials for a real provider (Gmail app password, Resend/SendGrid key). Leave both empty for an open relay such as Mailpit, which rejects an AUTH attempt |
| `EMAIL_FAILURE_RATE` | worker | 0‥1 chance of a simulated send failure (demo retries) |
| `WORKER_CONCURRENCY` | worker | Jobs processed in parallel per queue |
| `UPLOAD_DIR` | backend | Avatar storage directory |
| `INBOUND_SYNC_ENABLED` / `INBOUND_POLL_SECONDS` | worker | Import replies from the sending mailbox over IMAP |
| `SEED_DEMO_DATA` | seed | Seed the demo accounts. Defaults to `true` except when `NODE_ENV=production` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` / `ADMIN_FIRST_NAME` / `ADMIN_LAST_NAME` | seed | Create this Super Admin if it does not exist (how production gets its first account) |
| `NEXT_PUBLIC_SHOW_DEMO_ACCOUNTS` | frontend (build) | Show the demo-account shortcuts in a production build |
| `BACKEND_INTERNAL_URL` | frontend | Where Next.js proxies `/api`, `/uploads`, `/admin/queues` |

## Database

```bash
cd backend
npm run db:migrate   # prisma migrate dev     — create a new migration during development
npm run db:deploy    # prisma migrate deploy  — apply migrations (CI / prod / docker)
npm run db:seed      # idempotent seed (upserts; safe to re-run)
npm run db:reset     # drop + re-apply + seed (destructive, dev only)
```

### Schema

```
roles ─┬─< role_permissions >─── permissions
       └─< users ─┬─< project_members >── projects ─< tasks
                  ├─< projects (manager_id)            │
                  ├─< tasks (assignee_id, created_by) ─┘
                  ├─< activity_logs
                  ├─< notifications
                  └─< refresh_tokens
email_logs  (outbox + mailbox: recipient, sender, rendered body, read state)
```

- **Foreign keys** are chosen deliberately:
  - Deleting a role that still has users is `RESTRICT`ed (the API returns `409 ROLE_IN_USE`).
  - Memberships, notifications and refresh tokens `CASCADE` with their parent.
  - Audit and authorship columns use `SET NULL`, so history survives when a user is removed.
- **Soft delete** (`deleted_at`) applies to users, projects and tasks. Deleting a project soft-deletes its tasks in the same transaction.
- **Transactions** are used for:
  - replacing a role's permission set;
  - creating or updating a project together with its member set;
  - deleting a project together with its tasks;
  - rotating refresh tokens.
- **Timestamps** are `timestamptz(3)`. Date-only business fields (`start_date`, `due_date`) use `date`.

### Important indexes

| Index | Why |
| --- | --- |
| `users_email_active_key` — **partial unique** `(email) WHERE deleted_at IS NULL` | Rejects duplicate emails among live users, but still lets a soft-deleted user's email be reused. Emails are lower-cased before storage. |
| `users (status, deleted_at)`, `users (role_id)`, `users (created_at)` | User list filters, role → users lookups, default sort |
| `role_permissions` PK `(role_id, permission_id)` + `(permission_id)` | Loads a role's permissions; reverse lookup when a permission is removed |
| `project_members` PK `(project_id, user_id)` + `(user_id)` | The reverse index powers **data scoping** ("projects I'm a member of") |
| `projects (manager_id)`, `projects (status, deleted_at)`, `projects (deleted_at, created_at)` | Scoping by manager, status filter, default listing |
| `tasks (project_id, status)` | Project task board and progress counts |
| `tasks (assignee_id, status)` | "My open tasks" and employee scoping |
| `tasks (due_date)` | Sorting and overdue queries |
| `activity_logs (created_at DESC)`, `(user_id, created_at DESC)`, `(entity, entity_id)`, `(action)` | Feed paging, per-user history, per-entity history, action filter |
| `notifications (user_id, read_at, created_at DESC)` | Unread badge count and the notification dropdown with one index |
| `refresh_tokens (token_hash)` unique, `(family_id)`, `(expires_at)` | Token lookup, revoking a whole family on reuse, cleanup |
| GIN **trigram** indexes on user names/email, project name, task title | `ILIKE '%term%'` search without sequential scans (`pg_trgm`) |

> The partial unique index and the trigram indexes live in hand-written SQL (`prisma/migrations/20260915090000_users_email_partial_unique`), because Prisma's schema language can't express them. If you generate a new migration with `prisma migrate dev`, delete any `DROP INDEX` lines it adds for these indexes.

## Architecture

```
                 ┌──────────────────────────┐
  Browser ──────▶│ Next.js (frontend :3000) │  /api/*, /uploads/*, /admin/queues → rewrite
                 └────────────┬─────────────┘
                              ▼
                 ┌──────────────────────────┐        ┌──────────────┐
                 │ Express API (backend)    │───────▶│ PostgreSQL   │
                 │ auth · RBAC · validation │        └──────▲───────┘
                 └──────┬─────────────┬─────┘               │
         cache / rate   │             │ enqueue             │
         limit / pubsub ▼             ▼                     │
                 ┌──────────────────────────┐        ┌──────┴───────┐
                 │ Redis                    │◀──────▶│ Worker       │──▶ SMTP (Mailpit)
                 │ cache · rl · BullMQ · ps │ jobs   │ BullMQ       │
                 └──────────────────────────┘        └──────────────┘
```

### Backend (`backend/src`)

```
config/env.ts            zod-validated configuration
lib/                     prisma, redis, logger singletons
common/
  errors/                AppError hierarchy (Validation, NotFound, Unauthorized, Forbidden, Conflict, RateLimit)
  middleware/            authenticate, requirePermission, rate-limit, http-logger, error-handler
  http/                  response envelope, pagination, shared Prisma selects
cache/                   CacheService (versioned namespaces), SlidingWindowRateLimiter
queue/                   queues, producers, processors (email, activity), mailer, templates
modules/<feature>/       *.routes → *.controller → *.service → *.repository → Prisma
docs/openapi.ts          OpenAPI 3 document
app.ts / server.ts / worker.ts
```

- **Layering**: requests go Route → Controller → Service → Repository → Prisma.
  - **Routes** declare permissions.
  - **Controllers** only parse input and shape responses.
  - **Services** hold all business rules: scoping, escalation guards, status transitions, cache invalidation and activity events.
  - **Repositories** encapsulate query construction such as scoping `where` clauses and sort whitelists.
- **One codebase, two processes.** The worker (`src/worker.ts`) shares the Prisma client, config, logger and job types with the API. In Docker it is a separate container built from the same image with a different command, so it can scale on its own. This fits the scope better than a separate `worker/` package that would duplicate schema and types.
- **Graceful shutdown**: on `SIGTERM`/`SIGINT` the API stops accepting connections and drains in-flight requests, then closes queues, the Redis subscriber, Redis and Prisma. The worker calls `worker.close()`, which lets active jobs finish. A hard-exit timer guarantees the process terminates.

### Frontend (`frontend/`)

```
app/(auth)/login               cinematic "PLAYER LOGIN" screen
app/(app)/…                    dashboard, users, roles, projects, tasks, activity, system, profile
components/ui                  HUD design-system primitives (Button, Panel, Badge, XpBar, Dialog, Select, Tabs…)
components/data-table          reusable table: search, filters, sorting, pagination, row actions, skeleton/empty/error, mobile cards
components/<feature>           feature components (forms, lists, detail views)
components/auth                AuthProvider, <Can>, <RequirePermission>
hooks/                         TanStack Query hooks per resource + URL-synced table params
services/                      typed API calls per resource
lib/api/client.ts              fetch wrapper: envelopes, typed ApiError, single-flight refresh + retry
middleware.ts                  redirect to /login when no session cookie (UX only)
```

- **Server and client components**: layouts and pages are server components. Interactive views (tables, forms, dashboards) are client components that use TanStack Query for caching, background refetching and cache invalidation after mutations. Changing a task's status uses an optimistic update.
- **Same-origin API**: Next.js rewrites `/api/*` to the backend. Auth cookies are therefore first-party, the browser needs no CORS preflight, and the backend URL never reaches client bundles.
- **Forms** use react-hook-form with zod schemas that mirror the backend rules. They show inline errors, disable the submit button while pending, and show success toasts. Server `VALIDATION_ERROR.details` and `USER_EMAIL_EXISTS` are mapped back onto the matching fields.
- **Design system ("HUD")**:
  - Tailwind v4 `@theme` tokens; Orbitron, Rajdhani and JetBrains Mono fonts.
  - Chamfered `clip-path` panels, neon focus rings, and an animated grid and scanline background that respects `prefers-reduced-motion`.
  - Game-style visual metaphors: rarity tags for status, rank badges for roles, signal bars for priority, segmented XP bars for progress.
  - Fully responsive: below `lg` the sidebar becomes a drawer, and tables collapse into cards.

## Authentication

- **Login** checks the password with bcrypt (cost 12; 4 in tests). A dummy hash is compared when the email is unknown, so response timing doesn't reveal which accounts exist. On success it issues two httpOnly, `SameSite=Lax` cookies:
  - `tf_access`: a 15-minute HS256 JWT `{ sub, tv }`, path `/`.
  - `tf_refresh`: an opaque 256-bit random token, path `/api/auth`, 7 days. Only its SHA-256 hash is stored in the database.
- **Refresh token rotation**: every `POST /api/auth/refresh` revokes the presented token and issues a new one in the same *family*.
  - Presenting an already-rotated token counts as **token theft**. The whole family is revoked and an `auth.refresh_token_reused` audit event is written.
  - A 10-second grace window lets two tabs refresh at the same moment without logging the user out.
- **Access token checks** in the auth middleware:
  - It verifies the JWT, then loads the user's auth context (status, role, `tokenVersion`) from Redis, falling back to Postgres.
  - Changing a password, deactivating or deleting a user increments `tokenVersion` and revokes their refresh tokens, so **existing access tokens stop working immediately** instead of at expiry.
- `Authorization: Bearer <token>` is also accepted, for Swagger and scripts. Login returns `accessToken` in the body for that purpose.
- **Responses**: a missing or invalid token gets `401 UNAUTHENTICATED`; a lacking permission gets `403 FORBIDDEN`.
- **Proactive refresh (no 401s in normal use)**: because the access cookie is httpOnly, every authenticated response carries `X-Session-Expires-At`.
  - The API client refreshes one minute before that time.
  - If the timer was throttled (sleeping laptop, background tab), it refreshes right before the next request. The expiry is kept in `localStorage`, so this also works after a reload.
  - A non-secret `tf_session` marker cookie (path `/`) tells the Next.js middleware that a refreshable session exists, so a reload after the access token lapsed doesn't bounce through `/login`.
  - The notification stream reconnects after a session refresh.
  - As a last resort, the client refreshes once on a 401, retries, and otherwise redirects to `/login?next=…`.

## RBAC

- **Permissions** are `module.action` strings, defined once in `permission-catalog.ts` and seeded into `permissions`:
  - `users.view|create|update|delete`
  - `roles.view|create|update|delete`
  - `projects.view|create|update|delete|view_all`
  - `tasks.view|create|update|delete|view_all`
  - `activity_logs.view|export`
  - `emails.view|send|send_external|view_all`
  - `queues.view|manage`
- **Roles** are many-to-many with permissions (`role_permissions`). Each user has exactly one role.
- **Enforcement layers** (the backend is the security boundary):
  1. **Route guard**: `requirePermission('users.delete')` returns 403 before a controller runs.
  2. **Data scoping** in services and repositories. Without `projects.view_all`, a user only sees projects they manage or belong to. Without `tasks.view_all`, they only see tasks assigned to them, created by them, or in projects they manage. Anything out of scope returns **404**, so its existence isn't leaked.
  3. **Field-level rules**: a user who is not the project manager and lacks `tasks.view_all` may only PATCH `{ status }`, and only on tasks assigned to them.
  4. **Escalation guards**:
     - You can't assign a role that has permissions you don't hold.
     - You can't grant a role permissions you don't hold.
     - You can't delete, deactivate or change the role of yourself.
     - System roles can't be deleted, and Super Admin's permission set is locked.
- **Permission lookups** are cached in Redis (`rbac:role:{roleId}:perms`). Updating a role invalidates its entry, so changes apply on the next request without a re-login.
- **Frontend**:
  - `/api/auth/me` returns `permissions[]`; `usePermissions().can()`, `<Can>` and `<RequirePermission>` decide what to show.
  - Sidebar items, buttons and row actions without permission are not rendered, and guarded routes show an **ACCESS DENIED** screen.
  - This is UX only: the Employee hides the Delete button, but `curl -X DELETE /api/users/:id` with an employee cookie still returns 403.

| | Super Admin | Admin | Manager | Employee |
| --- | :-: | :-: | :-: | :-: |
| users.view / create / update / delete | ✔ ✔ ✔ ✔ | ✔ ✔ ✔ ✔ | ✔ – – – | – |
| roles.view / create / update / delete | ✔ ✔ ✔ ✔ | ✔ – – – | – | – |
| projects.view / create / update / delete / view_all | all | all | ✔ ✔ ✔ – – | ✔ – – – – |
| tasks.view / create / update / delete / view_all | all | all | ✔ ✔ ✔ ✔ – | ✔ – ✔ – – |
| activity_logs.view / export | ✔ ✔ | ✔ ✔ | ✔ – | – |
| emails.view / send / send_external / view_all | ✔ ✔ ✔ ✔ | ✔ ✔ ✔ ✔ | ✔ ✔ – – | ✔ ✔ – – |
| queues.view / manage | ✔ ✔ | ✔ – | – | – |

## Mailbox

`/emails` is an in-app mail client backed by the `email_logs` outbox, so every message the system sends is also readable in the UI.

| Folder | Contents | Query |
| --- | --- | --- |
| **Inbox** | Mail addressed to you | `toUserId = me` |
| **Sent** | Mail your actions produced — creating a user, or composing a message | `fromUserId = me` |
| **All Mail** | Every message in the system (`emails.view_all`) | unscoped |

- **Composing** (`emails.send`): pick a team member, or type any email address. An address belonging to an active user is resolved to them, so the message lands in their Inbox *and* goes out over SMTP.
- Sending to an address that is **not** a team member additionally needs `emails.send_external`. Such a message leaves from the organisation's own `SMTP_FROM` identity and carries its SPF/DKIM, so it is not something every role should be able to emit. An address belonging to a deactivated or deleted account is refused outright rather than treated as an external stranger.
- The rendered body is stored on the row at enqueue time, so a message is readable while still `QUEUED` and after it has `FAILED` — not only once delivery succeeds.
- Bodies render in a `sandbox=""` iframe: mail HTML cannot inherit app styles or run scripts.
- **Replying** threads the new message under the original via `reply_to_id`. The recipient is fixed to the other party, and the server refuses a `replyToId` you are not a party to — otherwise any id would let someone attach mail to a stranger's thread. System mail (a task assignment, a welcome) has no author, so it offers no Reply.
- **Deleting** is a *per-side soft delete*. One row is both parties' copy of the message, so `deleted_by_to_at` and `deleted_by_from_at` are set independently: it leaves your folder, the other party keeps theirs, and the delivery record survives for the admin audit view. A deleted message also stops being fetchable by id, so a stale link cannot reopen it. `emails.view_all` is a **read** permission — an administrator can see everyone's mail but cannot delete a message that is not theirs.
- Read state belongs to the recipient only; opening a message in Sent or All Mail never marks it read.
- `GET /api/emails/stats` drives the **Email traffic** strip on the System monitor and is scoped system-wide for `emails.view_all`, otherwise to your own mail.

### Endpoints

| Method | Path | Notes |
| --- | --- | --- |
| `GET` | `/api/emails?box=inbox\|sent\|all` | Paginated, `search`, `status`, `unreadOnly`. Bodies omitted |
| `GET` | `/api/emails/stats` | Counters for the monitor strip and unread badge |
| `POST` | `/api/emails` | `toUserId` **or** `toEmail`, `subject`, `body`, optional `replyToId` |
| `GET` | `/api/emails/{id}` | Adds the rendered body and the thread parent |
| `PATCH` | `/api/emails/{id}/read` | `{ read: boolean }` — recipient only |
| `DELETE` | `/api/emails/{id}` | Per-side soft delete; sender or recipient only |

## Outgoing mail

Two paths share one pipeline. In-app messages and transactional mail both become an `email_logs` row plus a BullMQ job; the worker is the only thing that talks to SMTP, so **credentials never reach the frontend or the API process's responses**.

```
API  ──▶  email_logs row (QUEUED)  ──▶  Redis / BullMQ  ──▶  worker  ──▶  Nodemailer  ──▶  Mailpit | Gmail
                                                                │
                                                                └─▶ row marked SENT / FAILED
```

Templates live in `backend/src/queue/templates.ts`. They share one `layout()` — dark shell, accent kicker, optional detail rows, one CTA, footer — so a new template is a description of *what to say*, not another copy of the markup. Every variable is HTML-escaped; author-written prose keeps its line breaks and nothing else.

| Template | Fired by |
| --- | --- |
| `welcome` | A user account is created |
| `message` | Someone composes mail in `/emails` |
| `task_assigned` | A task gains an assignee |
| `task_status_changed` | A task moves status — mailed to its author, never to whoever moved it |
| `project_invitation` | A user is added to a project |

Transactional producers never throw: the write has already committed, so a mail problem must not fail it. They also carry a derived job id (`task-assigned:<task>:<assignee>`), so a retried API call or a double-submit reuses the existing job instead of sending twice.

### Choosing a transport

`EMAIL_PROVIDER` selects it outright, so moving between environments is configuration rather than code:

| Value | Transport | Use |
| --- | --- | --- |
| `mailpit` | `SMTP_HOST:SMTP_PORT`, unauthenticated | Local development. Mailpit is an open relay and **rejects** an AUTH attempt |
| `gmail` | `smtp.gmail.com:587` with `GMAIL_USER` / `GMAIL_APP_PASSWORD` | Production |
| `smtp` | The `SMTP_*` values | Any other provider |
| `log` | None — the message is serialised | Tests, or a stack with no mail at all |

Left unset, the provider is inferred from `SMTP_HOST` exactly as earlier versions did, so an existing `.env` keeps working.

**Nothing addressed to a real person leaves a development machine.** Outside `NODE_ENV=production`, a provider that can reach real inboxes is refused with a `BlockedMailError` unless `EMAIL_ALLOW_REAL_SEND=true`. That refusal is *unrecoverable*: BullMQ fails the job immediately instead of burning five retries on a decision that will not change.

An account configured in **System → Email delivery** (stored AES-256-GCM encrypted in `mail_settings`) overrides `EMAIL_PROVIDER` and is subject to the same guard.

### Using the official Gmail account

1. Turn on **2-Step Verification** for the account — Google will not issue an App Password without it.
2. Create one at <https://myaccount.google.com/apppasswords>. You get 16 characters; the spaces Google shows are cosmetic.
3. Set it, without committing it:

   ```bash
   EMAIL_PROVIDER=gmail
   GMAIL_USER=official-company@gmail.com
   GMAIL_APP_PASSWORD=xxxxxxxxxxxxxxxx
   NODE_ENV=production            # or EMAIL_ALLOW_REAL_SEND=true to send from a dev box
   ```

   Gmail rewrites the sender, so mail always leaves as `GMAIL_USER` whatever `SMTP_FROM` says.
4. Restart the worker. It verifies the connection at boot and logs `SMTP connection successful` — or exactly what is wrong.

Never use the account's own password: Google rejects it for SMTP once 2-Step Verification is on. Credentials live only in the worker's environment; no API response and no frontend bundle ever contains them.

### Troubleshooting

| Symptom | Cause |
| --- | --- |
| `SMTP connection failed` + `EAUTH` | Not an App Password, or it was issued for a different account than `GMAIL_USER` |
| `... is a remote server but no credentials are set` | `EMAIL_PROVIDER=gmail` with `GMAIL_APP_PASSWORD` empty. Every send would be rejected, so boot verification fails loudly instead |
| `Refusing to deliver: NODE_ENV=development ...` | The dev guard. Use `EMAIL_PROVIDER=mailpit`, or set `EMAIL_ALLOW_REAL_SEND=true` if you meant it |
| Jobs complete but nothing arrives | No provider configured, so `log` was inferred. Nodemailer still returns a `messageId` |
| `ECONNECTION` / `ETIMEDOUT` | Port 587 blocked, or Mailpit is not running |

Failed jobs are visible three ways: **System → Email outbox** (`status`, `attempts`, `lastError`), the Bull Board at `/admin/queues`, and the `email-dead-letter` queue, which keeps every job that exhausted its five attempts for inspection or manual replay.

## Settings

`/settings` (in the player menu, no permission required) holds per-user preferences, stored as a JSON bag on `users.preferences` and returned with `/api/auth/me`.

| Setting | Values |
| --- | --- |
| Theme | `dark`, `light`, `system` (follows the OS live) |
| Accent | `cyan`, `violet`, `magenta`, `lime`, `amber` |
| Density | `comfortable`, `compact` |

- The whole palette is CSS custom properties, so a theme is a token override rather than a component rewrite. `--color-cyan` doubles as the accent slot: redefining it recolours every `text-cyan` / `border-cyan` in the app.
- Light mode keeps the grid backdrop and chamfered corners but drops the glow and scanlines, which read as smudging and banding on a light ground.
- Density is one token, `--row-py`, consumed by the shared table and list rows.
- **Signed-in devices**: the same page lists every active session — one per refresh-token family, with the calling device marked — and can sign out one device or all the others. Revoking clears refresh tokens only; `tokenVersion` is per-user, so bumping it would log the caller out too. The revoked device keeps a working access token for at most 15 minutes and then cannot refresh.
- A small inline script in `app/layout.tsx` stamps `data-theme` / `data-accent` / `data-density` onto `<html>` from `localStorage` **before first paint**; without it every reload would flash the dark theme. The server copy wins once `/auth/me` resolves.

## Caching & rate limiting

### What is cached

| Endpoint | Scope in key | Invalidated by |
| --- | --- | --- |
| `GET /api/projects` | `all` if the user has `projects.view_all`, else `u:{userId}` | project create/update/delete, membership changes, task mutations (progress counts) |
| `GET /api/dashboard` | derived from the caller's permission set and user id | user, project and task mutations, and new activity from the worker |
| Auth context `auth:user:{id}` | — | user update, status change, deletion, password change |
| Role permissions `rbac:role:{id}:perms` | — | role update or delete |

### Key strategy: versioned namespaces

```
cache:projects:v            → 17            (INCR on every write)
cache:projects:v17:all:9f2c…  → JSON        (scope + stable hash of normalised query params)
```

- **Reads** fetch the namespace version and build the key from it.
- **Writes** invalidate the whole namespace with a single `INCR`: O(1), with no `KEYS`/`SCAN` and no race between listing and deleting keys. Orphaned entries expire through their TTL.
- **Timing**: invalidation runs *after* the database transaction commits.
- **Redis outages**: the cache is read-through and degrades gracefully. If Redis is down, requests go straight to Postgres and a warning is logged.
- **Observability**: responses carry `X-Cache: HIT|MISS`.

### Rate limiting

- **Algorithm**: a sliding-window log, implemented as an **atomic Lua script** over a Redis sorted set (`rl:{bucket}:{ip}`). It stays correct across multiple API replicas.
- **Login**: 5 attempts per minute per IP. The global API limit is configurable.
- **Headers**: `RateLimit-Limit`, `RateLimit-Remaining`, `RateLimit-Reset` on every response, plus `Retry-After` and `429 RATE_LIMITED` when the limit is hit.

## Background jobs

```
POST /api/users ─▶ tx commit ─▶ email_logs(QUEUED) + queue.add('welcome') ─▶ 201 (API does not wait)
                                                    │
                                   worker ◀─────────┘  send via SMTP
                                     ├─ success → email_logs SENT
                                     ├─ throw   → retry: exponential backoff 2s, 4s, 8s, 16s (5 attempts)
                                     └─ final failure → email_logs FAILED + copy to `email-dead-letter`
```

| Queue | Producer | Worker behaviour |
| --- | --- | --- |
| `email` | `producers.welcomeEmail()` after a user is created, `producers.taskAssignedEmail()` when a task gains an assignee, and `producers.userMessage()` when someone composes mail in the Mailbox | Renders a template and sends it with nodemailer. `attempts: 5`, `backoff: exponential 2000ms`. Every attempt is logged with `jobId` and attempt number; attempts and last error are stored on `email_logs`. |
| `activity` | `activityService.record()`, called from services after commit | Writes the `activity_logs` row, creates notifications (task assigned → assignee, added to project → member), invalidates dashboard caches, and publishes to Redis `notifications:{userId}` for live updates. `attempts: 8`. If enqueueing fails, the event is written synchronously so no audit entry is lost. |
| `email-dead-letter` | the email worker's `failed` handler on the final attempt | Keeps the job payload and error for inspection and manual retry. |

- **Startup check**: the worker calls `verifyTransport()` on boot and logs `SMTP connection successful` or `SMTP connection failed` with the reason — so a broken mail setup shows up once at boot instead of one failed delivery at a time. It logs whether `SMTP_USER`/`SMTP_PASS` are *set*, never their values. A remote host with empty credentials is reported as a failure: `verify()` alone would pass, because with no `auth` block it never authenticates.
- **Task assignment mail**: `task.service.ts` fires `producers.taskAssignedEmail()` after the task row commits, alongside the existing in-app notification. It never throws, so a mail problem cannot fail a task write. The BullMQ job id is `task-assigned:{taskId}:{assigneeId}`, so replaying the same assignment (a retried request, a double submit) reuses the existing job instead of sending twice.
- **Failure demo**:
  - Any address containing `+fail` (for example `demo+fail@timeflow.dev`) always throws.
  - `EMAIL_FAILURE_RATE=0.5` makes about half of all sends fail randomly.
  - Watch the retries in **System → Jobs → Delayed/Failed** or in Bull Board, then press **Retry**.
- **Monitoring**: the in-app **System monitor** (`/system`) shows live queue counts, jobs by state, a retry button (`queues.manage`) and the email outbox. Bull Board is at `/admin/queues`, protected by the same cookie auth plus `queues.view`.
- **Real-time notifications**: `GET /api/notifications/stream` is an SSE endpoint fed by Redis pub/sub. The header bell invalidates its data when an event arrives, and falls back to polling every 30 s.

## Security

| Concern | Implementation |
| --- | --- |
| Password storage | bcrypt, cost 12; hashes never leave the service layer (explicit Prisma `select`s) |
| Authentication | httpOnly, SameSite cookies; short-lived JWT; rotated, hashed refresh tokens with reuse detection |
| Authorization | route guards, data scoping, field-level rules and escalation guards, all server-side |
| Input validation | zod for body, query and params; bodies are `.strict()` |
| Mass assignment | strict schemas reject unknown keys; services map explicit field whitelists into Prisma (for example, `roleId` needs the escalation check and `status` can't be set through the profile) |
| Injection | Prisma parameterised queries only; `sortBy` values are whitelisted |
| Rate limiting | Redis sliding window: login and global limits |
| Headers | `helmet` (CSP for the API, HSTS, noSniff, frameguard…), `x-powered-by` disabled |
| CORS | explicit origin allowlist with credentials; browser traffic is same-origin through the Next.js proxy anyway |
| Uploads | multer with MIME and extension allowlist (png, jpeg, webp), 2 MB limit, random file names, served with `nosniff` |
| Request size | JSON body limit of 100 kB |
| Secrets | environment variables only; `.env*` is gitignored and `.env.example` is documented |
| Information leakage | out-of-scope entities return 404; 500 responses hide internals (the stack is logged, never returned) |

## Error handling & logging

- **Errors**:
  - Services throw typed `AppError`s, for example `new ConflictError('Email already exists', 'USER_EMAIL_EXISTS')`.
  - Express 5 forwards rejected promises to one central `errorHandler`, so controllers need no try/catch.
  - The handler maps `AppError`, `ZodError` (to `400 VALIDATION_ERROR` with `details[]`), Prisma `P2002`/`P2025`/`P2003`, malformed JSON and multer errors to the standard envelope, including `requestId`.
- **Logging**:
  - Structured JSON logs via **pino** and **pino-http**. Every request gets an `X-Request-Id` (taken from the incoming header or generated), which is added to every log line and echoed in the response.
  - Access logs include `method`, `route` (the pattern, e.g. `/api/users/:id`), `statusCode`, `responseTime`, `userId` and the error for 5xx responses.
  - `authorization`, `cookie`, `set-cookie`, `password`, `passwordHash`, `token` and `refreshToken` are **redacted**. A test asserts this.
  - Worker logs include queue, `jobId`, attempt and duration.

## Testing

```bash
# Backend — needs Postgres + Redis. Uses a dedicated DB (must contain "test") and Redis DB 1.
cd backend
cat > .env.test <<'EOF'
NODE_ENV=test
LOG_LEVEL=silent
DATABASE_URL=postgresql://<user>@localhost:5432/timeflow_test?schema=public
REDIS_URL=redis://localhost:6379/1
JWT_ACCESS_SECRET=test-only-secret-0123456789abcdef0123456789
RATE_LIMIT_API_MAX=10000
UPLOAD_DIR=./uploads-test
EOF
createdb timeflow_test
npm test               # 68 tests: global setup = migrate deploy → truncate → seed → flush Redis DB 1
npm run typecheck

# Frontend
cd frontend
npm test               # 27 tests (Vitest + React Testing Library + happy-dom)
npm run typecheck && npm run lint

# E2E (optional; needs the full stack running)
npx playwright install chromium && npm run test:e2e
```

| Suite | Covers |
| --- | --- |
| `auth.test.ts` | login success, wrong password, inactive account, `/me`, refresh rotation, **reuse detection revokes the family**, logout, login rate limit → 429 |
| `users.test.ts` | CRUD, search, filter, sort, pagination, duplicate email → 409 (case-insensitive), reusing a soft-deleted user's email, field-level validation → 400, strict body (mass assignment), employee list/delete → 403, **escalation guards** (admin can't create a Super Admin or modify a higher-privileged user), self delete/deactivate guard |
| `roles.test.ts` | create/edit/delete with permissions, **permission changes apply to live sessions** (cache invalidation), duplicate name, unknown permission, `ROLE_IN_USE`, system role and Super Admin protection, admin without `roles.update` → 403, users assigned to a role |
| `projects.test.ts` | CRUD, date validation, filter/search/sort/paginate, employee scoping, manager can't modify a project they don't manage, **cache MISS → HIT → invalidated on create/update/delete**, cache entries separated per scope |
| `tasks.test.ts` | CRUD, `completedAt` maintenance, partial PATCH keeps omitted fields, assignee must be a project member, `assigneeId=me`, **employee can only change the status of their own task**, can't see others' tasks, can't create/delete |
| `activity-processor.test.ts`, `email-processor.test.ts` | log persistence, notification fan-out, EmailLog SENT/FAILED, dead-letter on final attempt |
| `rate-limiter.test.ts` | sliding window admits, blocks and recovers |
| `uploads`, `docs-health`, `logging` | file type and size checks, OpenAPI and health endpoints, redaction |
| frontend `login-form`, `user-form` | validation, submit payload, server error and `USER_EMAIL_EXISTS` field mapping |
| frontend `permissions` | `<Can>`, `<RequirePermission>`, sidebar filtering, users table hides Delete without `users.delete` |
| frontend `crud-flow`, `api-client` | create project payload + toast; delete user through the confirm dialog; 401 → single refresh → retry |

CI (`.github/workflows/ci.yml`) runs backend typecheck and tests against Postgres and Redis service containers, and frontend typecheck, tests and production build.

## API documentation

- **Swagger UI**: http://localhost:4000/api/docs. Log in with `POST /api/auth/login`, copy `data.accessToken`, then click *Authorize*.
- **OpenAPI JSON**: http://localhost:4000/api/docs.json
- **Human-readable contract**: [`docs/api-contract.md`](docs/api-contract.md), which lists response envelopes, error codes, permissions per endpoint and scoping rules.

## Demo script

1. **Auth**: open http://localhost:3000, click the *Super Admin* chip, then **Press Start**. You land on the dashboard.
2. **RBAC**:
   - Log out and log in as *Employee*. Users, Roles and System are missing from the menu, and `/users` shows ACCESS DENIED.
   - Tasks shows only Leo's tasks, and the status switcher works while the other fields are read-only.
   - Then try the API directly:

     ```bash
     curl -s -c emp.txt -H 'content-type: application/json' \
       -d '{"email":"employee@timeflow.dev","password":"Password123!"}' localhost:4000/api/auth/login >/dev/null
     curl -s -b emp.txt -X DELETE localhost:4000/api/users/<any-user-id>   # → 403 FORBIDDEN
     ```
3. **CRUD**: as Admin, create a project, add members, create a task, change its status, edit it and delete it. Each step shows a toast, and entries appear in Activity Logs.
4. **Redis cache**:

   ```bash
   curl -s -c sa.txt -H 'content-type: application/json' \
     -d '{"email":"superadmin@timeflow.dev","password":"Password123!"}' localhost:4000/api/auth/login >/dev/null
   curl -s -b sa.txt -D - -o /dev/null localhost:4000/api/projects | grep -i x-cache   # MISS
   curl -s -b sa.txt -D - -o /dev/null localhost:4000/api/projects | grep -i x-cache   # HIT
   # edit any project in the UI (or PATCH it), then:
   curl -s -b sa.txt -D - -o /dev/null localhost:4000/api/projects | grep -i x-cache   # MISS again
   docker compose exec redis redis-cli --scan --pattern 'cache:projects*'
   ```
5. **Queue**: create a user. The API responds right away; the welcome email appears in Mailpit (http://localhost:8025) and as *SENT* under System → Email outbox.
6. **Failed job and retry**:
   - Create a user with the email `demo+fail@timeflow.dev`.
   - Under System → Email → *Delayed* you can watch the backoff between attempts. After 5 attempts the job moves to *Failed*, the outbox shows *FAILED*, and `email-dead-letter` gains a job.
   - Click **Retry** (the `+fail` address fails again; set `EMAIL_FAILURE_RATE` to test random recovery). `docker compose logs -f worker` shows each attempt.
7. **Rate limit**: submit a wrong password 6 times within a minute; the 6th attempt returns `429` with `Retry-After`.
8. **Docker**: run `docker compose down -v && docker compose up --build` to start from a clean state.

## Design decisions & trade-offs

- **Express + a hand-rolled layered structure instead of NestJS**: the controller → service → repository split and the middleware stay explicit and easy to review, without framework magic.
- **Prisma**: type-safe queries and migration history. Where the schema language falls short (partial unique index, trigram indexes), the SQL is written by hand and documented.
- **Cookies + same-origin proxy instead of storing tokens in localStorage**: tokens aren't reachable from JavaScript (XSS), CORS configuration in the browser disappears, and refresh-token rotation still works.
- **Soft delete + partial unique index**: the audit trail and foreign keys stay valid, and a removed user's email can be reused.
- **404 for out-of-scope resources**: an employee can't discover projects they're not part of by probing IDs.
- **Versioned cache namespaces**: O(1), race-free invalidation for list endpoints whose keys vary with filters and user scope. The cost is some memory held by orphaned keys until their TTL expires (60 s).
- **Activity through a queue with a synchronous fallback**: audit writes and notification fan-out stay out of the request path, and events are never dropped if Redis briefly fails to accept a job.
- **Worker in the backend package**: it shares types, schema and config; operational isolation comes from running it as a separate container.
- **Known limitations and next steps**:
  - Forgot/reset password and email verification are not built. The token model and email queue already support them.
  - Uploads go to a local volume; an S3-compatible adapter would go behind the same upload service.
  - Access JWTs use HS256 with a single secret; multi-service deployments should move to asymmetric keys.
