/**
 * Local production deployment under pm2 — the non-Docker counterpart of
 * docker-compose.yml. Build first with `npm run deploy` (scripts/deploy-local.sh).
 *
 *   timeflow-api     http://localhost:4000   Express API
 *   timeflow-worker  (no port)                BullMQ worker: email, activity, inbox sync
 *   timeflow-web     http://localhost:3000   Next.js standalone server
 *
 * Postgres, Redis and (optionally) Mailpit are expected to be running already.
 * The backend reads everything else from backend/.env; the values below only
 * override what must differ from local development. dotenv never overrides a
 * variable that is already set, so these win.
 */
const path = require('node:path');

const backend = path.join(__dirname, 'backend');
const web = path.join(__dirname, 'frontend', '.next', 'standalone');
const logs = path.join(__dirname, 'logs');

const backendEnv = {
  NODE_ENV: 'production',
  PORT: '4000',
  LOG_LEVEL: 'info',
};

module.exports = {
  apps: [
    {
      name: 'timeflow-api',
      cwd: backend,
      script: 'dist/src/server.js',
      env: backendEnv,
      max_memory_restart: '512M',
      out_file: path.join(logs, 'api.log'),
      error_file: path.join(logs, 'api.log'),
      time: true,
    },
    {
      name: 'timeflow-worker',
      cwd: backend,
      script: 'dist/src/worker.js',
      env: backendEnv,
      // The worker drains in-flight jobs on SIGTERM; give it the time it asks for.
      kill_timeout: 30000,
      max_memory_restart: '512M',
      out_file: path.join(logs, 'worker.log'),
      error_file: path.join(logs, 'worker.log'),
      time: true,
    },
    {
      name: 'timeflow-web',
      cwd: web,
      script: 'server.js',
      env: {
        NODE_ENV: 'production',
        PORT: '3000',
        // 0.0.0.0 so other devices on the network can open http://<this-mac-ip>:3000.
        HOSTNAME: '0.0.0.0',
        BACKEND_INTERNAL_URL: 'http://127.0.0.1:4000',
        NEXT_TELEMETRY_DISABLED: '1',
      },
      max_memory_restart: '512M',
      out_file: path.join(logs, 'web.log'),
      error_file: path.join(logs, 'web.log'),
      time: true,
    },
  ],
};
