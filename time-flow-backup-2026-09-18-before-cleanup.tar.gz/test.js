/**
 * Gmail delivery test — app se bilkul alag.
 *
 * Ye script sirf ek kaam karta hai: Gmail SMTP se ek asli mail bhejta hai.
 * Isme koi queue, worker, database ya API nahi hai — isliye agar ye chal gaya
 * to problem Gmail/credentials me nahi hai, app me hai. Aur agar ye fail hua
 * to exact wajah batata hai.
 *
 * Chalane ka tarika:
 *   node test.js                      → khud ko mail bhejega (GMAIL_USER)
 *   node test.js koi@gmail.com        → us address par bhejega
 *
 * Credentials kabhi is file me mat likhna — backend/.env se aate hain.
 */

const path = require('node:path');

// nodemailer aur dotenv backend ke node_modules me hain, root me nahi.
const BACKEND = path.join(__dirname, 'backend');
const nodemailer = require(path.join(BACKEND, 'node_modules', 'nodemailer'));
require(path.join(BACKEND, 'node_modules', 'dotenv')).config({ path: path.join(BACKEND, '.env') });

// GMAIL_* documented naam hain; SMTP_* par fallback isliye ki purani .env bhi chale.
const user = process.env.GMAIL_USER || process.env.SMTP_USER;
const pass = process.env.GMAIL_APP_PASSWORD || process.env.SMTP_PASS;
const to = process.argv[2] || user;

function fail(message, hint) {
  console.error(`\n❌ ${message}`);
  if (hint) console.error(`\n${hint}`);
  process.exit(1);
}

async function main() {
  console.log('─'.repeat(60));
  console.log('  GMAIL DELIVERY TEST');
  console.log('─'.repeat(60));
  console.log(`  From : ${user || '(not set)'}`);
  console.log(`  To   : ${to || '(not set)'}`);
  // Password kabhi print nahi karna — sirf ye ki set hai ya nahi.
  console.log(`  App password : ${pass ? `set (${pass.length} chars)` : 'NOT SET'}`);
  console.log('─'.repeat(60));

  if (!user) {
    fail(
      'GMAIL_USER set nahi hai.',
      'backend/.env me daalein:\n  GMAIL_USER=aapka-account@gmail.com',
    );
  }

  if (!pass) {
    fail(
      'GMAIL_APP_PASSWORD set nahi hai.',
      'Gmail ka normal password kaam NAHI karega — Google use SMTP ke liye reject karta hai.\n' +
        '\n  1. 2-Step Verification ON karein : https://myaccount.google.com/security' +
        '\n  2. App Password banayein         : https://myaccount.google.com/apppasswords' +
        '\n  3. 16 characters (spaces hata kar) backend/.env me paste karein:' +
        '\n       GMAIL_APP_PASSWORD=abcdefghijklmnop',
    );
  }

  // Google App Password hamesha 16 characters ka hota hai. Galti se normal
  // password ya spaces-sameth value paste karna sabse aam wajah hai EAUTH ki.
  const cleaned = pass.replace(/\s+/g, '');
  if (cleaned.length !== 16) {
    console.warn(
      `\n⚠️  App password ${cleaned.length} characters ka hai, 16 hona chahiye.` +
        '\n   Shayad normal password paste ho gaya hai. Aage badh raha hoon, par EAUTH aa sakta hai.\n',
    );
  }

  const transport = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false, // 587 STARTTLS use karta hai; 465 ke liye true hota hai
    auth: { user, pass: cleaned },
  });

  // Step 1 — connection + login. Yahin 90% problems pakdi jati hain.
  console.log('\n[1/2] smtp.gmail.com:587 se connect kar raha hoon...');
  await transport.verify();
  console.log('      ✅ Connected aur login successful');

  // Step 2 — asli mail.
  console.log('[2/2] Mail bhej raha hoon...');
  const info = await transport.sendMail({
    // Gmail kisi bhi doosre sender ko apne aap badal deta hai, isliye From
    // hamesha wahi account rahega jisse login kiya hai.
    from: `TimeFlow Test <${user}>`,
    to,
    subject: 'TimeFlow — Gmail test mail',
    text: 'Agar ye mail aapko dikh rahi hai, to Gmail SMTP sahi kaam kar raha hai.',
    html:
      '<div style="font-family:system-ui,sans-serif;padding:24px;background:#0b0f1a;color:#e2e8f0">' +
      '<h2 style="color:#22d3ee;margin:0 0 8px">Gmail test mail</h2>' +
      '<p>Agar ye mail aapko dikh rahi hai, to Gmail SMTP sahi kaam kar raha hai.</p>' +
      `<p style="color:#64748b;font-size:12px">Bheja gaya: ${new Date().toLocaleString()}</p>` +
      '</div>',
  });

  console.log('      ✅ Accepted by Gmail');
  console.log(`\n  messageId : ${info.messageId}`);
  console.log(`  accepted  : ${info.accepted.join(', ') || '(none)'}`);
  if (info.rejected.length) console.log(`  rejected  : ${info.rejected.join(', ')}`);
  console.log(`\n🎉 Ho gaya. Ab ${to} ka inbox check karein (Spam folder bhi dekh lein).\n`);
}

main().catch((err) => {
  const code = err && err.code;
  const first = String((err && err.message) || err).split('\n')[0];

  // Jo do errors practice me actually aate hain, unka fix — symptom nahi.
  const hints = {
    EAUTH:
      'Gmail ne credentials reject kar diye. Iski teen wajah hoti hain:\n' +
      '  • Normal Gmail password use kiya (App Password chahiye)\n' +
      '  • App Password kisi doosre account ka hai, GMAIL_USER ka nahi\n' +
      '  • 2-Step Verification off hai\n\n' +
      '  Naya banayein: https://myaccount.google.com/apppasswords',
    ECONNECTION: 'smtp.gmail.com:587 tak pahunch nahi paya. Network/firewall port 587 block kar raha ho sakta hai.',
    ETIMEDOUT: 'smtp.gmail.com:587 tak pahunch nahi paya. Network/firewall port 587 block kar raha ho sakta hai.',
    ENOTFOUND: 'DNS resolve nahi hua. Internet connection check karein.',
    EENVELOPE: `Recipient address Gmail ne reject kiya. "${to}" ek asli mailbox hona chahiye — @timeflow.dev jaise demo addresses bounce ho jate hain.`,
  };

  fail(`Mail nahi bheji ja saki — ${first}${code ? ` (${code})` : ''}`, hints[code]);
});
