#!/usr/bin/env bash
# Builds TimeFlow for production and (re)starts it under pm2 on this machine.
# Safe to re-run: every step is idempotent, and pm2 reloads running processes.
#
#   npm run deploy          build + migrate + start/reload
#   npm run deploy:status   process list
#   npm run deploy:logs     tail all logs
#   npm run deploy:stop     stop everything
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PM2="$ROOT/node_modules/.bin/pm2"

step() { printf '\n\033[1m▸ %s\033[0m\n' "$1"; }

step "Checking services"
pg_isready -q || { echo "PostgreSQL is not accepting connections on localhost:5432."; exit 1; }
[ "$(redis-cli ping 2>/dev/null)" = "PONG" ] || { echo "Redis is not answering on localhost:6379."; exit 1; }
[ -f "$ROOT/backend/.env" ] || { echo "backend/.env is missing — copy .env.example and fill it in."; exit 1; }
if lsof -nP -iTCP:3000 -iTCP:4000 -sTCP:LISTEN 2>/dev/null | grep -v '^COMMAND' | grep -vq PM2; then
  # A dev server (npm run dev) on the same ports would make pm2's processes crash-loop.
  if ! "$PM2" jlist 2>/dev/null | grep -q '"name":"timeflow-'; then
    echo "Ports 3000/4000 are already in use (a dev server?). Stop it first:"
    lsof -nP -iTCP:3000 -iTCP:4000 -sTCP:LISTEN
    exit 1
  fi
fi

step "Installing dependencies"
(cd "$ROOT" && npm install --no-audit --no-fund --silent)
(cd "$ROOT/backend" && npm install --no-audit --no-fund --silent)
(cd "$ROOT/frontend" && npm install --no-audit --no-fund --silent)

step "Building backend"
(cd "$ROOT/backend" && npm run build)

step "Migrating database"
# Applies pending migrations only; the seed syncs permissions and roles and skips
# demo data in production.
(cd "$ROOT/backend" && npx prisma migrate deploy && NODE_ENV=production node dist/prisma/seed.js)

step "Building frontend"
# Rewrites to the API are fixed at build time.
(cd "$ROOT/frontend" && BACKEND_INTERNAL_URL=http://127.0.0.1:4000 NEXT_TELEMETRY_DISABLED=1 npm run build)
# The standalone server does not include static assets; copy them in as the Dockerfile does.
rm -rf "$ROOT/frontend/.next/standalone/.next/static" "$ROOT/frontend/.next/standalone/public"
cp -R "$ROOT/frontend/.next/static" "$ROOT/frontend/.next/standalone/.next/static"
cp -R "$ROOT/frontend/public" "$ROOT/frontend/.next/standalone/public"

step "Starting processes"
mkdir -p "$ROOT/logs"
"$PM2" startOrReload "$ROOT/ecosystem.config.cjs" --update-env
"$PM2" save --force >/dev/null

step "Waiting for health checks"
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:4000/health/ready >/dev/null 2>&1 && curl -fsS -o /dev/null http://127.0.0.1:3000/login; then
    "$PM2" ls
    printf '\n\033[32m✔ TimeFlow is running\033[0m\n'
    echo "  App:     http://localhost:3000"
    echo "  API:     http://localhost:4000   (docs: /api/docs)"
    ip="$(ipconfig getifaddr en0 2>/dev/null || true)"
    [ -n "$ip" ] && echo "  Network: http://$ip:3000"
    exit 0
  fi
  sleep 2
done
echo "Services did not become healthy in 60s. Recent logs:"
"$PM2" logs --lines 40 --nostream
exit 1
